<?php
session_start();
include 'config.php';

if(isset($_POST['wallid'])){
	$wallet = $_POST['wallid'];
	$ref = $_POST['ref'];
	
	if($wallet == ""){
		header("Location: ?wallet_empty");
		die();
	}
	if($ref == ""){
		$ref = 'none';
	}
	if($wallet == $ref){
		header("Location: ?nice_try");
		die();
	}
	$time = time();
	$sql = "SELECT * FROM wallets WHERE wallet = '$wallet'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$_SESSION['wallet'] = $row['wallet'];
			$_SESSION['balance'] = $row['balance'];
			header("Location: earn.php");
			die("Success!");
		}
	} else {
		if($ref == "none"){
			
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,"https://faucethub.io/api/v1/checkaddress");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,
					"api_key=$apikey&address=$wallet&currency=$shortcurrency");
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
	
			$check = json_decode($server_output,true);
			if($check['status'] == "200"){
				$sql = "INSERT INTO wallets (id, wallet, ref, balance, refbal, timestamp)VALUES ('', '$wallet', '$ref', '0', '0', '$time')";

				if ($conn->query($sql) === TRUE) {
					$_SESSION['wallet'] = $wallet;
					$_SESSION['balance'] = '0';
					header("Location: earn.php");
					die("Success!");
				}
			} else {
				header("Location: ?wallet_not_found");
				die("Your Wallet is not Linked to FaucetHub.IO");
			} 
			
		} else {
			$sql = "SELECT wallet FROM wallets WHERE wallet = '$ref'";
			$result = $conn->query($sql);

			if ($result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					$sql = "INSERT INTO wallets(id, wallet, ref, balance, refbal, timestamp)VALUES('', '$wallet', '$ref', '0', '0', '$time')";
					if ($conn->query($sql) === TRUE) {
						$_SESSION['wallet'] = $wallet;
						$_SESSION['balance'] = '0';
						header("Location: earn.php");
						die("Success!");
					} else {
						header("Location: ?e1");
						die("ERROR!");
					}
				}
			} else {
				$sql = "INSERT INTO wallets(id, wallet, ref, balance, refbal, timestamp)VALUES('', '$wallet', 'none', '0', '0', '$time')";
				if ($conn->query($sql) === TRUE) {
					$_SESSION['wallet'] = $wallet;
					$_SESSION['balance'] = '0';
					header("Location: earn.php");
					die("Success!");
				} else {
					header("Location: ?e2");
					die("ERROR!");
				}
			}
		}
	}
}



?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="https://ophosting.club">
    <link rel="icon" href="">
    <title><?php echo $website; ?> - Earn <?php echo $currency; ?> just by clicking.</title>
    <link href="http://cdn.flareco.net/bootstrap/css/bootstrap.css" rel="stylesheet">
	<link href="http://cdn.flareco.net/bootswatch/superhero/bootstrap.css" rel="stylesheet">
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <link href="css/jumbotron-narrow.css" rel="stylesheet">
    <script src="js/ie-emulation-modes-warning.js"></script>
</head>
<body>
	<div class="container">
		<div class="header clearfix">
			<nav>
				<ul class="nav nav-pills pull-right">
					<li role="presentation" class="active"><a href="index.php">Home</a></li>
				</ul>
			</nav>
			<h1><?php echo $website; ?></h1>
		</div>
		<div class="jumbotron">
			<h1>How it works ?</h1>
			<p>Earn <?php echo $currency; ?> by visiting Websites. For 10 seconds</p>
			<h3><b>Insert your FaucetHub.IO <?php echo $currency; ?> Wallet below :</b></h3>
			<form action="" method="POST">
				<input type="textbox" name="wallid" style="width:506px;height:38px;">
				<input type="hidden" name="ref" style="width:506px;height:38px;" value="<?php echo $_GET['ref']; ?>">
				<br>
				<br>
				<p><input type="submit" class="btn btn-lg btn-success" name="login" value="Start Now"></p>
			</form>
		</div>
		<center><h2><b>Sponsors</b></h2></center>
		<br>
		<center><img src="img/ptcw.jpg"></center>
	</div>
    <br>
<footer class="footer">
	<center> &copy; 2017 <?php echo $website; ?> </center>
</footer>
</div>
<!-----
	<div id="fake-container-for-00Webhost"></div>
</body>
</html>
