<?php
session_start();
include 'config.php';

if(!isset($_SESSION['wallet'])){
	header("Location: index.php?not_logged_in");
	die("Authentication Failed!");
}

if(isset($_GET['logout'])){
	session_destroy();
	header("Location: index.php?logged_out");
	die("You Logged Out :(");
}
$wallet = $_SESSION['wallet'];

$sql = "SELECT * FROM wallets WHERE wallet = '$wallet'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		$id = $row['id'];
        $balance = $row['balance'];
		$refbalance = $row['refbal'];
		$refid = $row['ref'];
    }
}


?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="https://ophosting.club">
    <link rel="icon" href="">
    <title><?php echo $website; ?> - Earn <?php echo $currency; ?> just by clicking.</title>
    <link href="http://satoshiptc.us/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <link href="css/jumbotron-narrow.css" rel="stylesheet">
    <script src="js/ie-emulation-modes-warning.js"></script>
</head>
<body>
	<div class="container">
		<div class="header clearfix">
			<nav>
				<ul class="nav nav-pills pull-right">
					<li role="presentation" class="active"><a href="earn.php">Dashboard</a></li>
					<li role="presentation"><a href="affiliate.php">Affiliate</a></li>
					<li role="presentation"><a href="?logout">Log Out</a></li>
				</ul>
			</nav>
			<h1><?php echo $website; ?></h1>
		</div>
		<h3>Your wallet : <?php echo $wallet; ?></h3><!------Your Ref: <?php echo $refid; ?>------->
		<h3>Total Earnings : <?php echo $balance; ?> | Ref Earnings: <?php echo $refbalance; ?></h3>
		<h3><b>PTC Ads :</b></h3>
		<iframe name="iframebody" src="http://www.ptcwall.com/index.php?view=ptcwall&pubid=<?php echo $pubid; ?>&usrid=<?php echo $id; ?>" style="height: 800px; width: 100%; border: 0;"></iframe>
		<br>
		<br>
		<font color="red"><b><h3>Your Reward will be sent instantly to your Wallet. (<?php echo $currency; ?>)</h3></b></font>
	</div>
</div>
     <br>
</div>
<footer class="footer">
	<center> &copy; 2017 <?php echo $website; ?> </center>
</footer>
</div>
	<script src="js/ie10-viewport-bug-workaround.js"></script>
</body>
</html>
