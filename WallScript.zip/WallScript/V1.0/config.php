<?php

//Website Settings
$website = ''; // ILOVEMONEY
$weburl = ''; // https://myepicurl.com/   ATTENTION PLEASE INCLUDE THE "/" AT THE END!
$currency = 'Bitcoin'; // Dogecoin, Blackckoin, Bitcoin, Peercoin, Litecoin, Dash, Primecoin
$refshare = '15'; //Percentage = 20 for 20%

//FaucetHub.io Settings
$shortcurrency = 'BTC'; //Only Uppercase (BTC, LTC, DOGE, ....)
$apikey = ''; // https://faucethub.io/manager/faucets

//PTCWall API
$pubid = ''; // Your Publisher ID
$postpass= ''; //Your Postback Password
//PTCWall, you need to select "Points" instead of Cash type during the "Add Site Registration"
//Normal you need to set the rate to "10000" or "100000"


//Database Settings
$dbhost = 'localhost';
$dbuser = '';
$dbpass = '';
$dbselect = '';

$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbselect);

//This script was made by FlareCO -> https://ophosting.club & http://flareco.net
//You are not allowed to resell this script!
?>