<?php
include 'config.php';


$sent_pw = $_REQUEST['pwd'];
$credited = trim($_REQUEST['r']);
$id = trim($_REQUEST['usr']);

$calc = $credited / 100;
$calc = $calc * $refshare;
$calc = floor($calc);


if($sent_pw == $postpass){
	
	$sql = "SELECT * FROM wallets WHERE id = '$id'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$wallet = $row['wallet'];
			$ref = $row['ref'];
			$checko = '1';
		}
	}
	
	if($checko == "1"){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,"https://faucethub.io/api/v1/send");
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS,
				"api_key=$apikey&to=$wallet&currency=$shortcurrency&amount=$credited");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$server_output = curl_exec ($ch);
		curl_close ($ch);
		
		$sql = "UPDATE wallets SET balance = balance + '$credited' where wallet = '$wallet'";
		$res = $conn->query($sql);
	}
	
	if($ref == "none"){
		die("ok");
	} else {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,"https://faucethub.io/api/v1/send");
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS,
				"api_key=$apikey&to=$wallet&currency=$shortcurrency&amount=$calc&referral=1");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$server_output = curl_exec ($ch);
		curl_close ($ch);
		
		$sql = "UPDATE wallets SET balance = balance + '$calc' where wallet = '$ref'";
		$res = $conn->query($sql);
	}
	
	die("ok");
} else {
	die("ok");
}
?>